// Copyright 2023 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// Generated code. DO NOT EDIT!

namespace GoogleCSharpSnippets
{
    using Google.Ai.Generativelanguage.V1Beta3;
    using Google.Api.Gax;
    using Google.Protobuf.WellKnownTypes;
    using System;
    using System.Linq;
    using System.Threading.Tasks;

    /// <summary>Generated snippets.</summary>
    public sealed class AllGeneratedPermissionServiceClientSnippets
    {
        /// <summary>Snippet for CreatePermission</summary>
        public void CreatePermissionRequestObject()
        {
            // Snippet: CreatePermission(CreatePermissionRequest, CallSettings)
            // Create client
            PermissionServiceClient permissionServiceClient = PermissionServiceClient.Create();
            // Initialize request argument(s)
            CreatePermissionRequest request = new CreatePermissionRequest
            {
                ParentAsTunedModelName = TunedModelName.FromTunedModel("[TUNED_MODEL]"),
                Permission = new Permission(),
            };
            // Make the request
            Permission response = permissionServiceClient.CreatePermission(request);
            // End snippet
        }

        /// <summary>Snippet for CreatePermissionAsync</summary>
        public async Task CreatePermissionRequestObjectAsync()
        {
            // Snippet: CreatePermissionAsync(CreatePermissionRequest, CallSettings)
            // Additional: CreatePermissionAsync(CreatePermissionRequest, CancellationToken)
            // Create client
            PermissionServiceClient permissionServiceClient = await PermissionServiceClient.CreateAsync();
            // Initialize request argument(s)
            CreatePermissionRequest request = new CreatePermissionRequest
            {
                ParentAsTunedModelName = TunedModelName.FromTunedModel("[TUNED_MODEL]"),
                Permission = new Permission(),
            };
            // Make the request
            Permission response = await permissionServiceClient.CreatePermissionAsync(request);
            // End snippet
        }

        /// <summary>Snippet for CreatePermission</summary>
        public void CreatePermission()
        {
            // Snippet: CreatePermission(string, Permission, CallSettings)
            // Create client
            PermissionServiceClient permissionServiceClient = PermissionServiceClient.Create();
            // Initialize request argument(s)
            string parent = "tunedModels/[TUNED_MODEL]";
            Permission permission = new Permission();
            // Make the request
            Permission response = permissionServiceClient.CreatePermission(parent, permission);
            // End snippet
        }

        /// <summary>Snippet for CreatePermissionAsync</summary>
        public async Task CreatePermissionAsync()
        {
            // Snippet: CreatePermissionAsync(string, Permission, CallSettings)
            // Additional: CreatePermissionAsync(string, Permission, CancellationToken)
            // Create client
            PermissionServiceClient permissionServiceClient = await PermissionServiceClient.CreateAsync();
            // Initialize request argument(s)
            string parent = "tunedModels/[TUNED_MODEL]";
            Permission permission = new Permission();
            // Make the request
            Permission response = await permissionServiceClient.CreatePermissionAsync(parent, permission);
            // End snippet
        }

        /// <summary>Snippet for CreatePermission</summary>
        public void CreatePermissionResourceNames()
        {
            // Snippet: CreatePermission(TunedModelName, Permission, CallSettings)
            // Create client
            PermissionServiceClient permissionServiceClient = PermissionServiceClient.Create();
            // Initialize request argument(s)
            TunedModelName parent = TunedModelName.FromTunedModel("[TUNED_MODEL]");
            Permission permission = new Permission();
            // Make the request
            Permission response = permissionServiceClient.CreatePermission(parent, permission);
            // End snippet
        }

        /// <summary>Snippet for CreatePermissionAsync</summary>
        public async Task CreatePermissionResourceNamesAsync()
        {
            // Snippet: CreatePermissionAsync(TunedModelName, Permission, CallSettings)
            // Additional: CreatePermissionAsync(TunedModelName, Permission, CancellationToken)
            // Create client
            PermissionServiceClient permissionServiceClient = await PermissionServiceClient.CreateAsync();
            // Initialize request argument(s)
            TunedModelName parent = TunedModelName.FromTunedModel("[TUNED_MODEL]");
            Permission permission = new Permission();
            // Make the request
            Permission response = await permissionServiceClient.CreatePermissionAsync(parent, permission);
            // End snippet
        }

        /// <summary>Snippet for GetPermission</summary>
        public void GetPermissionRequestObject()
        {
            // Snippet: GetPermission(GetPermissionRequest, CallSettings)
            // Create client
            PermissionServiceClient permissionServiceClient = PermissionServiceClient.Create();
            // Initialize request argument(s)
            GetPermissionRequest request = new GetPermissionRequest
            {
                PermissionName = PermissionName.FromTunedModelPermission("[TUNED_MODEL]", "[PERMISSION]"),
            };
            // Make the request
            Permission response = permissionServiceClient.GetPermission(request);
            // End snippet
        }

        /// <summary>Snippet for GetPermissionAsync</summary>
        public async Task GetPermissionRequestObjectAsync()
        {
            // Snippet: GetPermissionAsync(GetPermissionRequest, CallSettings)
            // Additional: GetPermissionAsync(GetPermissionRequest, CancellationToken)
            // Create client
            PermissionServiceClient permissionServiceClient = await PermissionServiceClient.CreateAsync();
            // Initialize request argument(s)
            GetPermissionRequest request = new GetPermissionRequest
            {
                PermissionName = PermissionName.FromTunedModelPermission("[TUNED_MODEL]", "[PERMISSION]"),
            };
            // Make the request
            Permission response = await permissionServiceClient.GetPermissionAsync(request);
            // End snippet
        }

        /// <summary>Snippet for GetPermission</summary>
        public void GetPermission()
        {
            // Snippet: GetPermission(string, CallSettings)
            // Create client
            PermissionServiceClient permissionServiceClient = PermissionServiceClient.Create();
            // Initialize request argument(s)
            string name = "tunedModels/[TUNED_MODEL]/permissions/[PERMISSION]";
            // Make the request
            Permission response = permissionServiceClient.GetPermission(name);
            // End snippet
        }

        /// <summary>Snippet for GetPermissionAsync</summary>
        public async Task GetPermissionAsync()
        {
            // Snippet: GetPermissionAsync(string, CallSettings)
            // Additional: GetPermissionAsync(string, CancellationToken)
            // Create client
            PermissionServiceClient permissionServiceClient = await PermissionServiceClient.CreateAsync();
            // Initialize request argument(s)
            string name = "tunedModels/[TUNED_MODEL]/permissions/[PERMISSION]";
            // Make the request
            Permission response = await permissionServiceClient.GetPermissionAsync(name);
            // End snippet
        }

        /// <summary>Snippet for GetPermission</summary>
        public void GetPermissionResourceNames()
        {
            // Snippet: GetPermission(PermissionName, CallSettings)
            // Create client
            PermissionServiceClient permissionServiceClient = PermissionServiceClient.Create();
            // Initialize request argument(s)
            PermissionName name = PermissionName.FromTunedModelPermission("[TUNED_MODEL]", "[PERMISSION]");
            // Make the request
            Permission response = permissionServiceClient.GetPermission(name);
            // End snippet
        }

        /// <summary>Snippet for GetPermissionAsync</summary>
        public async Task GetPermissionResourceNamesAsync()
        {
            // Snippet: GetPermissionAsync(PermissionName, CallSettings)
            // Additional: GetPermissionAsync(PermissionName, CancellationToken)
            // Create client
            PermissionServiceClient permissionServiceClient = await PermissionServiceClient.CreateAsync();
            // Initialize request argument(s)
            PermissionName name = PermissionName.FromTunedModelPermission("[TUNED_MODEL]", "[PERMISSION]");
            // Make the request
            Permission response = await permissionServiceClient.GetPermissionAsync(name);
            // End snippet
        }

        /// <summary>Snippet for ListPermissions</summary>
        public void ListPermissionsRequestObject()
        {
            // Snippet: ListPermissions(ListPermissionsRequest, CallSettings)
            // Create client
            PermissionServiceClient permissionServiceClient = PermissionServiceClient.Create();
            // Initialize request argument(s)
            ListPermissionsRequest request = new ListPermissionsRequest
            {
                ParentAsResourceName = new UnparsedResourceName("a/wildcard/resource"),
            };
            // Make the request
            PagedEnumerable<ListPermissionsResponse, Permission> response = permissionServiceClient.ListPermissions(request);

            // Iterate over all response items, lazily performing RPCs as required
            foreach (Permission item in response)
            {
                // Do something with each item
                Console.WriteLine(item);
            }

            // Or iterate over pages (of server-defined size), performing one RPC per page
            foreach (ListPermissionsResponse page in response.AsRawResponses())
            {
                // Do something with each page of items
                Console.WriteLine("A page of results:");
                foreach (Permission item in page)
                {
                    // Do something with each item
                    Console.WriteLine(item);
                }
            }

            // Or retrieve a single page of known size (unless it's the final page), performing as many RPCs as required
            int pageSize = 10;
            Page<Permission> singlePage = response.ReadPage(pageSize);
            // Do something with the page of items
            Console.WriteLine($"A page of {pageSize} results (unless it's the final page):");
            foreach (Permission item in singlePage)
            {
                // Do something with each item
                Console.WriteLine(item);
            }
            // Store the pageToken, for when the next page is required.
            string nextPageToken = singlePage.NextPageToken;
            // End snippet
        }

        /// <summary>Snippet for ListPermissionsAsync</summary>
        public async Task ListPermissionsRequestObjectAsync()
        {
            // Snippet: ListPermissionsAsync(ListPermissionsRequest, CallSettings)
            // Create client
            PermissionServiceClient permissionServiceClient = await PermissionServiceClient.CreateAsync();
            // Initialize request argument(s)
            ListPermissionsRequest request = new ListPermissionsRequest
            {
                ParentAsResourceName = new UnparsedResourceName("a/wildcard/resource"),
            };
            // Make the request
            PagedAsyncEnumerable<ListPermissionsResponse, Permission> response = permissionServiceClient.ListPermissionsAsync(request);

            // Iterate over all response items, lazily performing RPCs as required
            await response.ForEachAsync((Permission item) =>
            {
                // Do something with each item
                Console.WriteLine(item);
            });

            // Or iterate over pages (of server-defined size), performing one RPC per page
            await response.AsRawResponses().ForEachAsync((ListPermissionsResponse page) =>
            {
                // Do something with each page of items
                Console.WriteLine("A page of results:");
                foreach (Permission item in page)
                {
                    // Do something with each item
                    Console.WriteLine(item);
                }
            });

            // Or retrieve a single page of known size (unless it's the final page), performing as many RPCs as required
            int pageSize = 10;
            Page<Permission> singlePage = await response.ReadPageAsync(pageSize);
            // Do something with the page of items
            Console.WriteLine($"A page of {pageSize} results (unless it's the final page):");
            foreach (Permission item in singlePage)
            {
                // Do something with each item
                Console.WriteLine(item);
            }
            // Store the pageToken, for when the next page is required.
            string nextPageToken = singlePage.NextPageToken;
            // End snippet
        }

        /// <summary>Snippet for ListPermissions</summary>
        public void ListPermissions()
        {
            // Snippet: ListPermissions(string, string, int?, CallSettings)
            // Create client
            PermissionServiceClient permissionServiceClient = PermissionServiceClient.Create();
            // Initialize request argument(s)
            string parent = "a/wildcard/resource";
            // Make the request
            PagedEnumerable<ListPermissionsResponse, Permission> response = permissionServiceClient.ListPermissions(parent);

            // Iterate over all response items, lazily performing RPCs as required
            foreach (Permission item in response)
            {
                // Do something with each item
                Console.WriteLine(item);
            }

            // Or iterate over pages (of server-defined size), performing one RPC per page
            foreach (ListPermissionsResponse page in response.AsRawResponses())
            {
                // Do something with each page of items
                Console.WriteLine("A page of results:");
                foreach (Permission item in page)
                {
                    // Do something with each item
                    Console.WriteLine(item);
                }
            }

            // Or retrieve a single page of known size (unless it's the final page), performing as many RPCs as required
            int pageSize = 10;
            Page<Permission> singlePage = response.ReadPage(pageSize);
            // Do something with the page of items
            Console.WriteLine($"A page of {pageSize} results (unless it's the final page):");
            foreach (Permission item in singlePage)
            {
                // Do something with each item
                Console.WriteLine(item);
            }
            // Store the pageToken, for when the next page is required.
            string nextPageToken = singlePage.NextPageToken;
            // End snippet
        }

        /// <summary>Snippet for ListPermissionsAsync</summary>
        public async Task ListPermissionsAsync()
        {
            // Snippet: ListPermissionsAsync(string, string, int?, CallSettings)
            // Create client
            PermissionServiceClient permissionServiceClient = await PermissionServiceClient.CreateAsync();
            // Initialize request argument(s)
            string parent = "a/wildcard/resource";
            // Make the request
            PagedAsyncEnumerable<ListPermissionsResponse, Permission> response = permissionServiceClient.ListPermissionsAsync(parent);

            // Iterate over all response items, lazily performing RPCs as required
            await response.ForEachAsync((Permission item) =>
            {
                // Do something with each item
                Console.WriteLine(item);
            });

            // Or iterate over pages (of server-defined size), performing one RPC per page
            await response.AsRawResponses().ForEachAsync((ListPermissionsResponse page) =>
            {
                // Do something with each page of items
                Console.WriteLine("A page of results:");
                foreach (Permission item in page)
                {
                    // Do something with each item
                    Console.WriteLine(item);
                }
            });

            // Or retrieve a single page of known size (unless it's the final page), performing as many RPCs as required
            int pageSize = 10;
            Page<Permission> singlePage = await response.ReadPageAsync(pageSize);
            // Do something with the page of items
            Console.WriteLine($"A page of {pageSize} results (unless it's the final page):");
            foreach (Permission item in singlePage)
            {
                // Do something with each item
                Console.WriteLine(item);
            }
            // Store the pageToken, for when the next page is required.
            string nextPageToken = singlePage.NextPageToken;
            // End snippet
        }

        /// <summary>Snippet for ListPermissions</summary>
        public void ListPermissionsResourceNames()
        {
            // Snippet: ListPermissions(IResourceName, string, int?, CallSettings)
            // Create client
            PermissionServiceClient permissionServiceClient = PermissionServiceClient.Create();
            // Initialize request argument(s)
            IResourceName parent = new UnparsedResourceName("a/wildcard/resource");
            // Make the request
            PagedEnumerable<ListPermissionsResponse, Permission> response = permissionServiceClient.ListPermissions(parent);

            // Iterate over all response items, lazily performing RPCs as required
            foreach (Permission item in response)
            {
                // Do something with each item
                Console.WriteLine(item);
            }

            // Or iterate over pages (of server-defined size), performing one RPC per page
            foreach (ListPermissionsResponse page in response.AsRawResponses())
            {
                // Do something with each page of items
                Console.WriteLine("A page of results:");
                foreach (Permission item in page)
                {
                    // Do something with each item
                    Console.WriteLine(item);
                }
            }

            // Or retrieve a single page of known size (unless it's the final page), performing as many RPCs as required
            int pageSize = 10;
            Page<Permission> singlePage = response.ReadPage(pageSize);
            // Do something with the page of items
            Console.WriteLine($"A page of {pageSize} results (unless it's the final page):");
            foreach (Permission item in singlePage)
            {
                // Do something with each item
                Console.WriteLine(item);
            }
            // Store the pageToken, for when the next page is required.
            string nextPageToken = singlePage.NextPageToken;
            // End snippet
        }

        /// <summary>Snippet for ListPermissionsAsync</summary>
        public async Task ListPermissionsResourceNamesAsync()
        {
            // Snippet: ListPermissionsAsync(IResourceName, string, int?, CallSettings)
            // Create client
            PermissionServiceClient permissionServiceClient = await PermissionServiceClient.CreateAsync();
            // Initialize request argument(s)
            IResourceName parent = new UnparsedResourceName("a/wildcard/resource");
            // Make the request
            PagedAsyncEnumerable<ListPermissionsResponse, Permission> response = permissionServiceClient.ListPermissionsAsync(parent);

            // Iterate over all response items, lazily performing RPCs as required
            await response.ForEachAsync((Permission item) =>
            {
                // Do something with each item
                Console.WriteLine(item);
            });

            // Or iterate over pages (of server-defined size), performing one RPC per page
            await response.AsRawResponses().ForEachAsync((ListPermissionsResponse page) =>
            {
                // Do something with each page of items
                Console.WriteLine("A page of results:");
                foreach (Permission item in page)
                {
                    // Do something with each item
                    Console.WriteLine(item);
                }
            });

            // Or retrieve a single page of known size (unless it's the final page), performing as many RPCs as required
            int pageSize = 10;
            Page<Permission> singlePage = await response.ReadPageAsync(pageSize);
            // Do something with the page of items
            Console.WriteLine($"A page of {pageSize} results (unless it's the final page):");
            foreach (Permission item in singlePage)
            {
                // Do something with each item
                Console.WriteLine(item);
            }
            // Store the pageToken, for when the next page is required.
            string nextPageToken = singlePage.NextPageToken;
            // End snippet
        }

        /// <summary>Snippet for UpdatePermission</summary>
        public void UpdatePermissionRequestObject()
        {
            // Snippet: UpdatePermission(UpdatePermissionRequest, CallSettings)
            // Create client
            PermissionServiceClient permissionServiceClient = PermissionServiceClient.Create();
            // Initialize request argument(s)
            UpdatePermissionRequest request = new UpdatePermissionRequest
            {
                Permission = new Permission(),
                UpdateMask = new FieldMask(),
            };
            // Make the request
            Permission response = permissionServiceClient.UpdatePermission(request);
            // End snippet
        }

        /// <summary>Snippet for UpdatePermissionAsync</summary>
        public async Task UpdatePermissionRequestObjectAsync()
        {
            // Snippet: UpdatePermissionAsync(UpdatePermissionRequest, CallSettings)
            // Additional: UpdatePermissionAsync(UpdatePermissionRequest, CancellationToken)
            // Create client
            PermissionServiceClient permissionServiceClient = await PermissionServiceClient.CreateAsync();
            // Initialize request argument(s)
            UpdatePermissionRequest request = new UpdatePermissionRequest
            {
                Permission = new Permission(),
                UpdateMask = new FieldMask(),
            };
            // Make the request
            Permission response = await permissionServiceClient.UpdatePermissionAsync(request);
            // End snippet
        }

        /// <summary>Snippet for UpdatePermission</summary>
        public void UpdatePermission()
        {
            // Snippet: UpdatePermission(Permission, FieldMask, CallSettings)
            // Create client
            PermissionServiceClient permissionServiceClient = PermissionServiceClient.Create();
            // Initialize request argument(s)
            Permission permission = new Permission();
            FieldMask updateMask = new FieldMask();
            // Make the request
            Permission response = permissionServiceClient.UpdatePermission(permission, updateMask);
            // End snippet
        }

        /// <summary>Snippet for UpdatePermissionAsync</summary>
        public async Task UpdatePermissionAsync()
        {
            // Snippet: UpdatePermissionAsync(Permission, FieldMask, CallSettings)
            // Additional: UpdatePermissionAsync(Permission, FieldMask, CancellationToken)
            // Create client
            PermissionServiceClient permissionServiceClient = await PermissionServiceClient.CreateAsync();
            // Initialize request argument(s)
            Permission permission = new Permission();
            FieldMask updateMask = new FieldMask();
            // Make the request
            Permission response = await permissionServiceClient.UpdatePermissionAsync(permission, updateMask);
            // End snippet
        }

        /// <summary>Snippet for DeletePermission</summary>
        public void DeletePermissionRequestObject()
        {
            // Snippet: DeletePermission(DeletePermissionRequest, CallSettings)
            // Create client
            PermissionServiceClient permissionServiceClient = PermissionServiceClient.Create();
            // Initialize request argument(s)
            DeletePermissionRequest request = new DeletePermissionRequest
            {
                PermissionName = PermissionName.FromTunedModelPermission("[TUNED_MODEL]", "[PERMISSION]"),
            };
            // Make the request
            permissionServiceClient.DeletePermission(request);
            // End snippet
        }

        /// <summary>Snippet for DeletePermissionAsync</summary>
        public async Task DeletePermissionRequestObjectAsync()
        {
            // Snippet: DeletePermissionAsync(DeletePermissionRequest, CallSettings)
            // Additional: DeletePermissionAsync(DeletePermissionRequest, CancellationToken)
            // Create client
            PermissionServiceClient permissionServiceClient = await PermissionServiceClient.CreateAsync();
            // Initialize request argument(s)
            DeletePermissionRequest request = new DeletePermissionRequest
            {
                PermissionName = PermissionName.FromTunedModelPermission("[TUNED_MODEL]", "[PERMISSION]"),
            };
            // Make the request
            await permissionServiceClient.DeletePermissionAsync(request);
            // End snippet
        }

        /// <summary>Snippet for DeletePermission</summary>
        public void DeletePermission()
        {
            // Snippet: DeletePermission(string, CallSettings)
            // Create client
            PermissionServiceClient permissionServiceClient = PermissionServiceClient.Create();
            // Initialize request argument(s)
            string name = "tunedModels/[TUNED_MODEL]/permissions/[PERMISSION]";
            // Make the request
            permissionServiceClient.DeletePermission(name);
            // End snippet
        }

        /// <summary>Snippet for DeletePermissionAsync</summary>
        public async Task DeletePermissionAsync()
        {
            // Snippet: DeletePermissionAsync(string, CallSettings)
            // Additional: DeletePermissionAsync(string, CancellationToken)
            // Create client
            PermissionServiceClient permissionServiceClient = await PermissionServiceClient.CreateAsync();
            // Initialize request argument(s)
            string name = "tunedModels/[TUNED_MODEL]/permissions/[PERMISSION]";
            // Make the request
            await permissionServiceClient.DeletePermissionAsync(name);
            // End snippet
        }

        /// <summary>Snippet for DeletePermission</summary>
        public void DeletePermissionResourceNames()
        {
            // Snippet: DeletePermission(PermissionName, CallSettings)
            // Create client
            PermissionServiceClient permissionServiceClient = PermissionServiceClient.Create();
            // Initialize request argument(s)
            PermissionName name = PermissionName.FromTunedModelPermission("[TUNED_MODEL]", "[PERMISSION]");
            // Make the request
            permissionServiceClient.DeletePermission(name);
            // End snippet
        }

        /// <summary>Snippet for DeletePermissionAsync</summary>
        public async Task DeletePermissionResourceNamesAsync()
        {
            // Snippet: DeletePermissionAsync(PermissionName, CallSettings)
            // Additional: DeletePermissionAsync(PermissionName, CancellationToken)
            // Create client
            PermissionServiceClient permissionServiceClient = await PermissionServiceClient.CreateAsync();
            // Initialize request argument(s)
            PermissionName name = PermissionName.FromTunedModelPermission("[TUNED_MODEL]", "[PERMISSION]");
            // Make the request
            await permissionServiceClient.DeletePermissionAsync(name);
            // End snippet
        }

        /// <summary>Snippet for TransferOwnership</summary>
        public void TransferOwnershipRequestObject()
        {
            // Snippet: TransferOwnership(TransferOwnershipRequest, CallSettings)
            // Create client
            PermissionServiceClient permissionServiceClient = PermissionServiceClient.Create();
            // Initialize request argument(s)
            TransferOwnershipRequest request = new TransferOwnershipRequest
            {
                TunedModelName = TunedModelName.FromTunedModel("[TUNED_MODEL]"),
                EmailAddress = "",
            };
            // Make the request
            TransferOwnershipResponse response = permissionServiceClient.TransferOwnership(request);
            // End snippet
        }

        /// <summary>Snippet for TransferOwnershipAsync</summary>
        public async Task TransferOwnershipRequestObjectAsync()
        {
            // Snippet: TransferOwnershipAsync(TransferOwnershipRequest, CallSettings)
            // Additional: TransferOwnershipAsync(TransferOwnershipRequest, CancellationToken)
            // Create client
            PermissionServiceClient permissionServiceClient = await PermissionServiceClient.CreateAsync();
            // Initialize request argument(s)
            TransferOwnershipRequest request = new TransferOwnershipRequest
            {
                TunedModelName = TunedModelName.FromTunedModel("[TUNED_MODEL]"),
                EmailAddress = "",
            };
            // Make the request
            TransferOwnershipResponse response = await permissionServiceClient.TransferOwnershipAsync(request);
            // End snippet
        }
    }
}
