// Copyright 2023 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// Generated code. DO NOT EDIT!

namespace GoogleCSharpSnippets
{
    using Google.Ai.Generativelanguage.V1Beta3;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    /// <summary>Generated snippets.</summary>
    public sealed class AllGeneratedTextServiceClientSnippets
    {
        /// <summary>Snippet for GenerateText</summary>
        public void GenerateTextRequestObject()
        {
            // Snippet: GenerateText(GenerateTextRequest, CallSettings)
            // Create client
            TextServiceClient textServiceClient = TextServiceClient.Create();
            // Initialize request argument(s)
            GenerateTextRequest request = new GenerateTextRequest
            {
                Model = "",
                Prompt = new TextPrompt(),
                Temperature = 0F,
                CandidateCount = 0,
                MaxOutputTokens = 0,
                TopP = 0F,
                TopK = 0,
                SafetySettings =
                {
                    new SafetySetting(),
                },
                StopSequences = { "", },
            };
            // Make the request
            GenerateTextResponse response = textServiceClient.GenerateText(request);
            // End snippet
        }

        /// <summary>Snippet for GenerateTextAsync</summary>
        public async Task GenerateTextRequestObjectAsync()
        {
            // Snippet: GenerateTextAsync(GenerateTextRequest, CallSettings)
            // Additional: GenerateTextAsync(GenerateTextRequest, CancellationToken)
            // Create client
            TextServiceClient textServiceClient = await TextServiceClient.CreateAsync();
            // Initialize request argument(s)
            GenerateTextRequest request = new GenerateTextRequest
            {
                Model = "",
                Prompt = new TextPrompt(),
                Temperature = 0F,
                CandidateCount = 0,
                MaxOutputTokens = 0,
                TopP = 0F,
                TopK = 0,
                SafetySettings =
                {
                    new SafetySetting(),
                },
                StopSequences = { "", },
            };
            // Make the request
            GenerateTextResponse response = await textServiceClient.GenerateTextAsync(request);
            // End snippet
        }

        /// <summary>Snippet for GenerateText</summary>
        public void GenerateText()
        {
            // Snippet: GenerateText(string, TextPrompt, float, int, int, float, int, CallSettings)
            // Create client
            TextServiceClient textServiceClient = TextServiceClient.Create();
            // Initialize request argument(s)
            string model = "";
            TextPrompt prompt = new TextPrompt();
            float temperature = 0F;
            int candidateCount = 0;
            int maxOutputTokens = 0;
            float topP = 0F;
            int topK = 0;
            // Make the request
            GenerateTextResponse response = textServiceClient.GenerateText(model, prompt, temperature, candidateCount, maxOutputTokens, topP, topK);
            // End snippet
        }

        /// <summary>Snippet for GenerateTextAsync</summary>
        public async Task GenerateTextAsync()
        {
            // Snippet: GenerateTextAsync(string, TextPrompt, float, int, int, float, int, CallSettings)
            // Additional: GenerateTextAsync(string, TextPrompt, float, int, int, float, int, CancellationToken)
            // Create client
            TextServiceClient textServiceClient = await TextServiceClient.CreateAsync();
            // Initialize request argument(s)
            string model = "";
            TextPrompt prompt = new TextPrompt();
            float temperature = 0F;
            int candidateCount = 0;
            int maxOutputTokens = 0;
            float topP = 0F;
            int topK = 0;
            // Make the request
            GenerateTextResponse response = await textServiceClient.GenerateTextAsync(model, prompt, temperature, candidateCount, maxOutputTokens, topP, topK);
            // End snippet
        }

        /// <summary>Snippet for EmbedText</summary>
        public void EmbedTextRequestObject()
        {
            // Snippet: EmbedText(EmbedTextRequest, CallSettings)
            // Create client
            TextServiceClient textServiceClient = TextServiceClient.Create();
            // Initialize request argument(s)
            EmbedTextRequest request = new EmbedTextRequest
            {
                ModelAsModelName = ModelName.FromModel("[MODEL]"),
                Text = "",
            };
            // Make the request
            EmbedTextResponse response = textServiceClient.EmbedText(request);
            // End snippet
        }

        /// <summary>Snippet for EmbedTextAsync</summary>
        public async Task EmbedTextRequestObjectAsync()
        {
            // Snippet: EmbedTextAsync(EmbedTextRequest, CallSettings)
            // Additional: EmbedTextAsync(EmbedTextRequest, CancellationToken)
            // Create client
            TextServiceClient textServiceClient = await TextServiceClient.CreateAsync();
            // Initialize request argument(s)
            EmbedTextRequest request = new EmbedTextRequest
            {
                ModelAsModelName = ModelName.FromModel("[MODEL]"),
                Text = "",
            };
            // Make the request
            EmbedTextResponse response = await textServiceClient.EmbedTextAsync(request);
            // End snippet
        }

        /// <summary>Snippet for EmbedText</summary>
        public void EmbedText()
        {
            // Snippet: EmbedText(string, string, CallSettings)
            // Create client
            TextServiceClient textServiceClient = TextServiceClient.Create();
            // Initialize request argument(s)
            string model = "models/[MODEL]";
            string text = "";
            // Make the request
            EmbedTextResponse response = textServiceClient.EmbedText(model, text);
            // End snippet
        }

        /// <summary>Snippet for EmbedTextAsync</summary>
        public async Task EmbedTextAsync()
        {
            // Snippet: EmbedTextAsync(string, string, CallSettings)
            // Additional: EmbedTextAsync(string, string, CancellationToken)
            // Create client
            TextServiceClient textServiceClient = await TextServiceClient.CreateAsync();
            // Initialize request argument(s)
            string model = "models/[MODEL]";
            string text = "";
            // Make the request
            EmbedTextResponse response = await textServiceClient.EmbedTextAsync(model, text);
            // End snippet
        }

        /// <summary>Snippet for EmbedText</summary>
        public void EmbedTextResourceNames()
        {
            // Snippet: EmbedText(ModelName, string, CallSettings)
            // Create client
            TextServiceClient textServiceClient = TextServiceClient.Create();
            // Initialize request argument(s)
            ModelName model = ModelName.FromModel("[MODEL]");
            string text = "";
            // Make the request
            EmbedTextResponse response = textServiceClient.EmbedText(model, text);
            // End snippet
        }

        /// <summary>Snippet for EmbedTextAsync</summary>
        public async Task EmbedTextResourceNamesAsync()
        {
            // Snippet: EmbedTextAsync(ModelName, string, CallSettings)
            // Additional: EmbedTextAsync(ModelName, string, CancellationToken)
            // Create client
            TextServiceClient textServiceClient = await TextServiceClient.CreateAsync();
            // Initialize request argument(s)
            ModelName model = ModelName.FromModel("[MODEL]");
            string text = "";
            // Make the request
            EmbedTextResponse response = await textServiceClient.EmbedTextAsync(model, text);
            // End snippet
        }

        /// <summary>Snippet for BatchEmbedText</summary>
        public void BatchEmbedTextRequestObject()
        {
            // Snippet: BatchEmbedText(BatchEmbedTextRequest, CallSettings)
            // Create client
            TextServiceClient textServiceClient = TextServiceClient.Create();
            // Initialize request argument(s)
            BatchEmbedTextRequest request = new BatchEmbedTextRequest
            {
                ModelAsModelName = ModelName.FromModel("[MODEL]"),
                Texts = { "", },
            };
            // Make the request
            BatchEmbedTextResponse response = textServiceClient.BatchEmbedText(request);
            // End snippet
        }

        /// <summary>Snippet for BatchEmbedTextAsync</summary>
        public async Task BatchEmbedTextRequestObjectAsync()
        {
            // Snippet: BatchEmbedTextAsync(BatchEmbedTextRequest, CallSettings)
            // Additional: BatchEmbedTextAsync(BatchEmbedTextRequest, CancellationToken)
            // Create client
            TextServiceClient textServiceClient = await TextServiceClient.CreateAsync();
            // Initialize request argument(s)
            BatchEmbedTextRequest request = new BatchEmbedTextRequest
            {
                ModelAsModelName = ModelName.FromModel("[MODEL]"),
                Texts = { "", },
            };
            // Make the request
            BatchEmbedTextResponse response = await textServiceClient.BatchEmbedTextAsync(request);
            // End snippet
        }

        /// <summary>Snippet for BatchEmbedText</summary>
        public void BatchEmbedText()
        {
            // Snippet: BatchEmbedText(string, IEnumerable<string>, CallSettings)
            // Create client
            TextServiceClient textServiceClient = TextServiceClient.Create();
            // Initialize request argument(s)
            string model = "models/[MODEL]";
            IEnumerable<string> texts = new string[] { "", };
            // Make the request
            BatchEmbedTextResponse response = textServiceClient.BatchEmbedText(model, texts);
            // End snippet
        }

        /// <summary>Snippet for BatchEmbedTextAsync</summary>
        public async Task BatchEmbedTextAsync()
        {
            // Snippet: BatchEmbedTextAsync(string, IEnumerable<string>, CallSettings)
            // Additional: BatchEmbedTextAsync(string, IEnumerable<string>, CancellationToken)
            // Create client
            TextServiceClient textServiceClient = await TextServiceClient.CreateAsync();
            // Initialize request argument(s)
            string model = "models/[MODEL]";
            IEnumerable<string> texts = new string[] { "", };
            // Make the request
            BatchEmbedTextResponse response = await textServiceClient.BatchEmbedTextAsync(model, texts);
            // End snippet
        }

        /// <summary>Snippet for BatchEmbedText</summary>
        public void BatchEmbedTextResourceNames()
        {
            // Snippet: BatchEmbedText(ModelName, IEnumerable<string>, CallSettings)
            // Create client
            TextServiceClient textServiceClient = TextServiceClient.Create();
            // Initialize request argument(s)
            ModelName model = ModelName.FromModel("[MODEL]");
            IEnumerable<string> texts = new string[] { "", };
            // Make the request
            BatchEmbedTextResponse response = textServiceClient.BatchEmbedText(model, texts);
            // End snippet
        }

        /// <summary>Snippet for BatchEmbedTextAsync</summary>
        public async Task BatchEmbedTextResourceNamesAsync()
        {
            // Snippet: BatchEmbedTextAsync(ModelName, IEnumerable<string>, CallSettings)
            // Additional: BatchEmbedTextAsync(ModelName, IEnumerable<string>, CancellationToken)
            // Create client
            TextServiceClient textServiceClient = await TextServiceClient.CreateAsync();
            // Initialize request argument(s)
            ModelName model = ModelName.FromModel("[MODEL]");
            IEnumerable<string> texts = new string[] { "", };
            // Make the request
            BatchEmbedTextResponse response = await textServiceClient.BatchEmbedTextAsync(model, texts);
            // End snippet
        }

        /// <summary>Snippet for CountTextTokens</summary>
        public void CountTextTokensRequestObject()
        {
            // Snippet: CountTextTokens(CountTextTokensRequest, CallSettings)
            // Create client
            TextServiceClient textServiceClient = TextServiceClient.Create();
            // Initialize request argument(s)
            CountTextTokensRequest request = new CountTextTokensRequest
            {
                ModelAsModelName = ModelName.FromModel("[MODEL]"),
                Prompt = new TextPrompt(),
            };
            // Make the request
            CountTextTokensResponse response = textServiceClient.CountTextTokens(request);
            // End snippet
        }

        /// <summary>Snippet for CountTextTokensAsync</summary>
        public async Task CountTextTokensRequestObjectAsync()
        {
            // Snippet: CountTextTokensAsync(CountTextTokensRequest, CallSettings)
            // Additional: CountTextTokensAsync(CountTextTokensRequest, CancellationToken)
            // Create client
            TextServiceClient textServiceClient = await TextServiceClient.CreateAsync();
            // Initialize request argument(s)
            CountTextTokensRequest request = new CountTextTokensRequest
            {
                ModelAsModelName = ModelName.FromModel("[MODEL]"),
                Prompt = new TextPrompt(),
            };
            // Make the request
            CountTextTokensResponse response = await textServiceClient.CountTextTokensAsync(request);
            // End snippet
        }

        /// <summary>Snippet for CountTextTokens</summary>
        public void CountTextTokens()
        {
            // Snippet: CountTextTokens(string, TextPrompt, CallSettings)
            // Create client
            TextServiceClient textServiceClient = TextServiceClient.Create();
            // Initialize request argument(s)
            string model = "models/[MODEL]";
            TextPrompt prompt = new TextPrompt();
            // Make the request
            CountTextTokensResponse response = textServiceClient.CountTextTokens(model, prompt);
            // End snippet
        }

        /// <summary>Snippet for CountTextTokensAsync</summary>
        public async Task CountTextTokensAsync()
        {
            // Snippet: CountTextTokensAsync(string, TextPrompt, CallSettings)
            // Additional: CountTextTokensAsync(string, TextPrompt, CancellationToken)
            // Create client
            TextServiceClient textServiceClient = await TextServiceClient.CreateAsync();
            // Initialize request argument(s)
            string model = "models/[MODEL]";
            TextPrompt prompt = new TextPrompt();
            // Make the request
            CountTextTokensResponse response = await textServiceClient.CountTextTokensAsync(model, prompt);
            // End snippet
        }

        /// <summary>Snippet for CountTextTokens</summary>
        public void CountTextTokensResourceNames()
        {
            // Snippet: CountTextTokens(ModelName, TextPrompt, CallSettings)
            // Create client
            TextServiceClient textServiceClient = TextServiceClient.Create();
            // Initialize request argument(s)
            ModelName model = ModelName.FromModel("[MODEL]");
            TextPrompt prompt = new TextPrompt();
            // Make the request
            CountTextTokensResponse response = textServiceClient.CountTextTokens(model, prompt);
            // End snippet
        }

        /// <summary>Snippet for CountTextTokensAsync</summary>
        public async Task CountTextTokensResourceNamesAsync()
        {
            // Snippet: CountTextTokensAsync(ModelName, TextPrompt, CallSettings)
            // Additional: CountTextTokensAsync(ModelName, TextPrompt, CancellationToken)
            // Create client
            TextServiceClient textServiceClient = await TextServiceClient.CreateAsync();
            // Initialize request argument(s)
            ModelName model = ModelName.FromModel("[MODEL]");
            TextPrompt prompt = new TextPrompt();
            // Make the request
            CountTextTokensResponse response = await textServiceClient.CountTextTokensAsync(model, prompt);
            // End snippet
        }
    }
}
